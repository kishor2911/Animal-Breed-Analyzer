# convert_model.py
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'

import pickle
import json
import numpy as np
from pathlib import Path
import tensorflow as tf
from tensorflow.keras.models import load_model

def convert_model():
    print("🔄 CONVERTING MODEL TO COMPATIBLE FORMAT...")
    
    model_path = Path('model/efficientnet_breed_classifier_final.pkl')
    metadata_path = Path('model/breed_names.json')
    
    if not model_path.exists():
        print("❌ Model file not found")
        return False
    
    try:
        # First, let's see what's in the pickle file
        print("📦 Inspecting pickle file...")
        with open(model_path, 'rb') as f:
            model = pickle.load(f)
        
        print(f"✅ Model type: {type(model)}")
        
        # Save as H5 format (more reliable)
        h5_path = Path('model/efficientnet_model.h5')
        print(f"💾 Saving as H5 format...")
        model.save(str(h5_path))
        print(f"✅ Model saved as H5: {h5_path}")
        
        # Test the H5 model
        print("🧪 Testing H5 model...")
        h5_model = load_model(str(h5_path))
        
        # Test with correct input shape
        dummy_input = np.random.random((1, 301, 301, 3)).astype(np.float32)
        predictions = h5_model.predict(dummy_input, verbose=0)
        print(f"✅ H5 model test successful! Output: {predictions.shape}")
        
        # Update metadata
        if metadata_path.exists():
            with open(metadata_path, 'r') as f:
                metadata = json.load(f)
            
            metadata['model_format'] = 'h5'
            metadata['input_shape'] = [301, 301, 3]
            metadata['compatible'] = True
            
            with open(metadata_path, 'w') as f:
                json.dump(metadata, f, indent=2)
            
            print("✅ Metadata updated")
        
        print("🎉 Model conversion successful!")
        return True
        
    except Exception as e:
        print(f"❌ Conversion failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    convert_model()