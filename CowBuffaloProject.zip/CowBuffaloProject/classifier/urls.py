from django.urls import path
from . import views

urlpatterns = [
    # Main pages
    path('', views.home, name='home'),  # Home page (breed analyzer)
    path('analyze/', views.analyze_image, name='analyze_image'),  # For POST requests
    path('chatbot/', views.chatbot_page, name='chatbot_page'),
    path('diagnostic/', views.diagnostic_view, name='diagnostic'),
    
    # API endpoints
    path('api/chat/', views.chat_api, name='chat_api'),
    path('api/test/', views.test_api, name='test_api'),
    path('api/models/', views.get_models, name='get_models'),  # This should work now
]