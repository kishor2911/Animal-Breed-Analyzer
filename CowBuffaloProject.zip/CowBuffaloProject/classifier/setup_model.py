# classifier/setup_model.py
import os
import json
import pathlib
from django.conf import settings

def create_model_structure():
    """Create the necessary model file structure"""
    PROJECT_ROOT = pathlib.Path(settings.BASE_DIR)
    MODEL_DIR = PROJECT_ROOT / 'classifier' / 'model'
    
    # Create model directory
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    print(f"✅ Created model directory: {MODEL_DIR}")
    
    # Create sample metadata (you'll replace this with your actual model)
    metadata = {
        "class_mapping": {
            "0": "Holstein",
            "1": "Jersey", 
            "2": "Angus",
            "3": "Jaffrabadi",
            "4": "Banni",
            "5": "Other"
        },
        "breed_types": {
            "Holstein": "cow",
            "Jersey": "cow",
            "Angus": "cow", 
            "Jaffrabadi": "buffalo",
            "Banni": "buffalo",
            "Other": "cow"
        },
        "input_shape": [300, 300, 3],
        "model_type": "EfficientNetB3",
        "total_classes": 6
    }
    
    metadata_path = MODEL_DIR / 'model_metadata.json'
    with open(metadata_path, 'w') as f:
        json.dump(metadata, f, indent=2)
    
    print(f"✅ Created metadata file: {metadata_path}")
    
    # Create placeholder model file (you'll replace this with your actual .h5 file)
    model_path = MODEL_DIR / 'cow_breed_model.h5'
    if not model_path.exists():
        with open(model_path, 'w') as f:
            f.write("# Placeholder for actual model file\n")
            f.write("# Replace this file with your trained model.h5 file\n")
        print(f"✅ Created placeholder model file: {model_path}")
        print("⚠️  Please replace this file with your actual trained model.h5 file")
    else:
        print(f"✅ Model file already exists: {model_path}")
    
    return MODEL_DIR

if __name__ == "__main__":
    create_model_structure()