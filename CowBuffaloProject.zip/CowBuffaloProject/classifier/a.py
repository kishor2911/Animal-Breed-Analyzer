import tensorflow as tf
import pickle
import numpy as np

# --- 1. Load the Keras Model (Required step) ---
h5_model_path = 'E:\CowBuffaloProject\model\efficientnet_breed_classifier_final.h5'
try:
    # Load the model from .h5
    model = tf.keras.models.load_model(h5_model_path, compile=False)
    
    # --- 2. Extract the data you want to pickle ---
    # A. Get the model weights (as a list of NumPy arrays)
    weights = model.get_weights() 
    
    # B. Get the class names (assuming you loaded them from breed_names.json)
    class_names = ['Holstein', 'Jersey', 'Banni', 'Jafarabadi'] 
    
    # --- 3. Save the list of weights and metadata to a .pkl file ---
    pkl_data = {
        'weights': weights,
        'class_names': class_names
    }

    pkl_file_path = 'model_data.pkl'
    with open(pkl_file_path, 'wb') as f:
        pickle.dump(pkl_data, f)
        
    print(f"✅ Successfully pickled weights and metadata to {pkl_file_path}")

except Exception as e:
    print(f"❌ Error during loading/pickling: {e}")