import os
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'  # Force CPU usage

import json
import base64
from io import BytesIO
import pathlib
import numpy as np
from PIL import Image
import logging
from django.shortcuts import render
from django.http import JsonResponse
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt

# ========== GEMINI AI CONFIGURATION ==========
try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False
    print("⚠️ Install: pip install google-generativeai")

# 🔥 GET YOUR FREE API KEY FROM: https://makersuite.google.com/app/apikey
API_KEY = "AIzaSyCY21fmj6F7jboqPMCuJ0kjtTshgeXyx0g"  # Replace with your key
# ============================================

# TensorFlow imports
try:
    import tensorflow as tf
    from tensorflow.keras.models import load_model
    TENSORFLOW_AVAILABLE = True
except ImportError:
    TENSORFLOW_AVAILABLE = False

# Configure Gemini
gemini_configured = False
chatbot = None

if GEMINI_AVAILABLE:
    def configure_gemini():
        """Configure Gemini with the API key"""
        global gemini_configured
        try:
            if not API_KEY or API_KEY == "YOUR_NEW_API_KEY_HERE":
                print("❌ Please replace API_KEY with your actual key")
                print("🔗 Get from: https://makersuite.google.com/app/apikey")
                return False
            
            genai.configure(api_key=API_KEY)
            print(f"✅ Gemini configured with key: {API_KEY[:15]}...")
            
            # Test connection
            try:
                models = genai.list_models()
                available_models = [m.name for m in models]
                gemini_models = [m for m in available_models if "gemini" in m.lower()]
                print(f"✅ Found {len(gemini_models)} Gemini models")
                gemini_configured = True
                return True
            except Exception as e:
                print(f"❌ API test failed: {e}")
                return False
                
        except Exception as e:
            print(f"❌ Config error: {e}")
            return False
    
    # Gemini Chatbot Class for 2.5 version
    class GeminiChat:
        def __init__(self):
            self.current_model = None
            self.available_models = []
            if gemini_configured:
                self.find_working_model()
        
        def find_working_model(self):
            """Find a working Gemini model"""
            try:
                models = genai.list_models()
                self.available_models = [m.name for m in models]
                
                # Try Gemini 2.5 Flash first (latest version)
                model_priority = [
                    "gemini-2.0-flash-exp",           # Latest experimental
                    "gemini-2.0-flash-thinking-exp",  # Thinking version
                    "gemini-2.0-flash-latest",        # Latest stable
                    "gemini-2.0-flash",              # Stable release
                    "gemini-1.5-flash-latest",       # Previous version
                    "gemini-1.5-flash",              # Previous stable
                    "gemini-1.5-pro-latest",         # Pro version
                    "gemini-1.5-pro",                # Pro stable
                ]
                
                print("🔄 Testing available models...")
                for model_name in model_priority:
                    if any(model_name in m for m in self.available_models):
                        full_model_name = next((m for m in self.available_models if model_name in m), None)
                        if full_model_name:
                            try:
                                print(f"  Testing: {full_model_name}")
                                model = genai.GenerativeModel(full_model_name)
                                
                                # Test with a simple message
                                response = model.generate_content(
                                    "Hello",
                                    generation_config=genai.types.GenerationConfig(
                                        temperature=0.1,
                                        max_output_tokens=10,
                                    )
                                )
                                
                                self.current_model = full_model_name
                                print(f"✅ Selected: {full_model_name}")
                                return full_model_name
                                
                            except Exception as e:
                                print(f"  ❌ {full_model_name}: {str(e)[:80]}")
                                continue
                
                # If no specific model found, try any gemini model
                for model_name in self.available_models:
                    if "gemini" in model_name.lower():
                        try:
                            print(f"  Trying: {model_name}")
                            model = genai.GenerativeModel(model_name)
                            response = model.generate_content("Test")
                            self.current_model = model_name
                            print(f"✅ Selected fallback: {model_name}")
                            return model_name
                        except:
                            continue
                
                print("❌ No working Gemini models found")
                return None
                
            except Exception as e:
                print(f"❌ Error finding models: {e}")
                return None
        
        def get_response(self, message):
            """Get response from Gemini"""
            if not gemini_configured or not self.current_model:
                return {
                    'success': False,
                    'error': 'Gemini not configured',
                    'text': '❌ Gemini API not configured. Please check API key.'
                }
            
            try:
                model = genai.GenerativeModel(self.current_model)
                
                response = model.generate_content(
                    f"""You are an expert animal breed assistant specializing in cows, buffaloes, dogs, and cats. 
                    User question: {message}
                    
                    Provide helpful, accurate information about animal breeds in a friendly tone.""",
                    generation_config=genai.types.GenerationConfig(
                        temperature=0.7,
                        max_output_tokens=1000,
                        top_p=0.8,
                        top_k=40
                    )
                )
                
                return {
                    'success': True,
                    'text': response.text,
                    'model': self.current_model
                }
                
            except Exception as e:
                error_msg = str(e)
                print(f"❌ Chat error: {error_msg}")
                
                # Try to find another model
                self.find_working_model()
                
                return {
                    'success': False,
                    'error': error_msg,
                    'text': f"❌ Error: Please try again. {error_msg[:100]}"
                }
    
    # Initialize Gemini
    configure_gemini()
    if gemini_configured:
        chatbot = GeminiChat()
        if chatbot.current_model:
            print(f"✅ Chatbot ready with model: {chatbot.current_model}")
        else:
            print("⚠️ Chatbot initialized but no working model")
            chatbot = None
    else:
        chatbot = None
else:
    print("⚠️ Gemini AI package not installed")

# ========== BREED CLASSIFICATION ==========
PROJECT_ROOT = pathlib.Path(settings.BASE_DIR)
MODEL_DIR = PROJECT_ROOT / 'classifier' / 'model'

MODEL_PATHS = {
    'cow': MODEL_DIR / 'cow_breed_model.keras',
    'buffalo': MODEL_DIR / 'buffalo_breed_model.keras',
    'dog': MODEL_DIR / 'dog_breed_model.keras',
    'cat': MODEL_DIR / 'cat_breed_model.keras'
}

CLASS_NAMES_PATHS = {
    'cow': MODEL_DIR / 'cow_class_names.json',
    'buffalo': MODEL_DIR / 'buffalo_class_names.json',
    'dog': MODEL_DIR / 'dog_class_names.json',
    'cat': MODEL_DIR / 'cat_class_names.json'
}

TARGET_SIZE = (224, 224)
_model_cache = {}

# Breed information database
BREED_INFO = {
    # Cow breeds
    'gir': {
        'description': "The Gir is a famous Indian dairy cattle breed originating from Gujarat. Known for its distinctive appearance with drooping ears and a large hump.",
        'origin': "Gujarat, India",
        'use': "Dairy production",
        'weight': "400-500 kg (females), 600-700 kg (males)",
        'features': "Reddish-brown coat, large hump, drooping ears, heat tolerant"
    },
    'ongole': {
        'description': "Ongole cattle are known for their strength and endurance, often used for draught purposes. They are white or light grey in color.",
        'origin': "Andhra Pradesh, India",
        'use': "Draft and dairy",
        'weight': "400-500 kg (females), 550-650 kg (males)",
        'features': "White/grey coat, strong build, large horns"
    },
    'holstein': {
        'description': "Holstein is the most common dairy cattle breed worldwide, known for high milk production with distinctive black and white markings.",
        'origin': "Netherlands",
        'use': "Dairy production",
        'weight': "600-700 kg (females), 900-1200 kg (males)",
        'features': "Black and white spots, large udder, high milk yield"
    },
    'jersey': {
        'description': "Jersey cattle are smaller dairy breed known for high butterfat content in milk. They are light brown in color with a dark nose.",
        'origin': "Jersey Island, UK",
        'use': "Dairy production",
        'weight': "400-500 kg (females), 600-800 kg (males)",
        'features': "Light brown color, dark muzzle, high milk fat"
    },
    
    # Buffalo breeds
    'murrah': {
        'description': "Murrah is the most popular Indian buffalo breed known for high milk yield. They have distinctive curved horns.",
        'origin': "Haryana, India",
        'use': "Dairy production",
        'weight': "500-600 kg (females), 700-800 kg (males)",
        'features': "Black coat, curved horns, high milk fat"
    },
    'jaffrabadi': {
        'description': "Jaffrabadi buffalo are massive animals known for high milk production. They are one of the heaviest buffalo breeds.",
        'origin': "Gujarat, India",
        'use': "Dairy production",
        'weight': "600-700 kg (females), 800-1000 kg (males)",
        'features': "Black coat, massive size, large curved horns"
    },
    'banni': {
        'description': "Banni buffalo are drought-resistant breed adapted to arid conditions of Kutch region. Known for milk with high fat content.",
        'origin': "Kutch, Gujarat, India",
        'use': "Dairy production",
        'weight': "450-550 kg (females), 600-700 kg (males)",
        'features': "Black coat, drought-resistant, high milk fat"
    },
    
    # Dog breeds (sample)
    'beagle': {
        'description': "Beagles are small to medium-sized hound dogs known for their excellent sense of smell and tracking instincts.",
        'origin': "England",
        'use': "Hunting, companion",
        'weight': "9-11 kg (20-25 lbs)",
        'features': "Tri-color coat, long ears, friendly nature"
    },
    'labrador': {
        'description': "Labrador Retrievers are friendly, energetic dogs originally bred as fishing and hunting companions.",
        'origin': "Newfoundland, Canada",
        'use': "Hunting, service, companion",
        'weight': "25-36 kg (55-80 lbs)",
        'features': "Short coat, otter tail, friendly disposition"
    },
    
    # Cat breeds (sample)
    'persian': {
        'description': "Persian cats are long-haired cats with a sweet face and calm personality. They require regular grooming.",
        'origin': "Persia (Iran)",
        'use': "Companion",
        'weight': "3-5 kg (7-12 lbs)",
        'features': "Long fur, flat face, calm temperament"
    },
    'siamese': {
        'description': "Siamese cats are known for their distinctive color points, blue eyes, and vocal nature.",
        'origin': "Thailand",
        'use': "Companion",
        'weight': "3-5 kg (6-11 lbs)",
        'features': "Color points, blue eyes, vocal personality"
    }
}

# ========== VIEW FUNCTIONS ==========

def home(request):
    """Home page - breed analyzer"""
    return analyze_image(request)

def analyze_image(request):
    """Handle breed analysis"""
    context = {
        'gemini_configured': gemini_configured,
        'selected_model': 'cow',
    }
    
    if chatbot:
        context['current_model'] = chatbot.current_model
    else:
        context['current_model'] = None

    if request.method == 'POST' and request.FILES.get('image_file'):
        model_type = request.POST.get('model_type', 'cow').lower()
        uploaded_file = request.FILES['image_file']
        
        context['selected_model'] = model_type

        # Load model
        model, class_mapping, breed_types, error_msg = load_model_and_metadata(model_type)
        if model is None:
            context['error'] = error_msg
            return render(request, 'classifier/index.html', context)

        try:
            image = Image.open(uploaded_file)
            model_input = preprocess_image(image)
            predictions = model.predict(model_input, verbose=0)[0]
            top_indices = np.argsort(predictions)[-3:][::-1]

            emoji_map = {'cow': '🐄', 'buffalo': '🐃', 'dog': '🐕', 'cat': '🐈'}

            results = []
            for idx in top_indices:
                confidence = float(predictions[idx]) * 100
                breed_name = class_mapping.get(str(idx), f"Breed {idx}")
                breed_type = breed_types.get(breed_name, model_type)
                
                # Get breed info
                breed_key = breed_name.lower().replace(' ', '_')
                breed_info = BREED_INFO.get(breed_key, {
                    'description': f"The {breed_name} is a {breed_type} breed.",
                    'origin': "Various regions",
                    'use': "Multiple purposes",
                    'weight': "Varies by individual",
                    'features': "Typical characteristics for the species"
                })
                
                results.append({
                    'breed': breed_name,
                    'type': breed_type,
                    'confidence': round(confidence, 2),
                    'emoji': emoji_map.get(model_type, '🐾'),
                    'description': breed_info['description'],
                    'origin': breed_info['origin'],
                    'use': breed_info['use'],
                    'weight': breed_info['weight'],
                    'features': breed_info['features']
                })

            # Convert image for display
            buffer = BytesIO()
            display_image = image.convert('RGB')
            display_image.thumbnail((400, 400))
            display_image.save(buffer, format='JPEG', quality=85)
            img_str = base64.b64encode(buffer.getvalue()).decode()
            image_data_url = f"data:image/jpeg;base64,{img_str}"

            context.update({
                'image_data_url': image_data_url,
                'results': results,
                'uploaded_image_name': uploaded_file.name,
                'success': True
            })

        except Exception as e:
            context['error'] = f"Error: {str(e)}"

    return render(request, 'classifier/index.html', context)

def chatbot_page(request):
    """Chatbot page"""
    context = {
        'gemini_configured': gemini_configured,
        'current_model': chatbot.current_model if chatbot else None,
    }
    return render(request, 'classifier/chatbot.html', context)

@csrf_exempt
def chat_api(request):
    """Handle chat requests"""
    if not chatbot:
        return JsonResponse({
            'success': False,
            'error': 'Chatbot not available',
            'reply': '❌ Chatbot is not configured. Please check API key.'
        })
    
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            user_message = data.get('message', '').strip()
            
            if not user_message:
                return JsonResponse({'success': False, 'error': 'Empty message'})
            
            response = chatbot.get_response(user_message)
            
            return JsonResponse({
                'success': response['success'],
                'reply': response['text'],
                'model': response.get('model', 'unknown')
            })
            
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': f"Error: {str(e)}"
            })
    
    return JsonResponse({'success': False, 'error': 'POST required'})

@csrf_exempt
def test_api(request):
    """Test API endpoint"""
    if not gemini_configured:
        return JsonResponse({
            'success': False,
            'error': 'Gemini not configured',
            'message': 'Please set a valid API key'
        })
    
    try:
        if chatbot:
            response = chatbot.get_response("Say 'Hello World' in one sentence")
            
            return JsonResponse({
                'success': response['success'],
                'test_response': response['text'] if response['success'] else response['error'],
                'current_model': chatbot.current_model,
                'available_models_count': len(chatbot.available_models),
                'api_key_preview': f"{API_KEY[:10]}..." if API_KEY else "None"
            })
        else:
            return JsonResponse({
                'success': False,
                'error': 'Chatbot not initialized'
            })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        })

def get_models(request):
    """Get available models"""
    if not chatbot:
        return JsonResponse({
            'success': False,
            'error': 'Chatbot not available'
        })
    
    return JsonResponse({
        'success': True,
        'current_model': chatbot.current_model,
        'available_models': chatbot.available_models[:10],  # First 10
        'total': len(chatbot.available_models)
    })

def diagnostic_view(request):
    """Diagnostic page"""
    diagnostics = {}
    
    for animal_type, model_path in MODEL_PATHS.items():
        class_path = CLASS_NAMES_PATHS[animal_type]
        
        diagnostics[animal_type] = {
            'model_exists': model_path.exists(),
            'class_file_exists': class_path.exists(),
            'model_path': str(model_path),
            'class_path': str(class_path),
        }

    context = {
        'tensorflow_available': TENSORFLOW_AVAILABLE,
        'gemini_configured': gemini_configured,
        'gemini_available': GEMINI_AVAILABLE,
        'current_model': chatbot.current_model if chatbot else None,
        'api_key': API_KEY[:10] + "..." if API_KEY else "None",
        'diagnostics': diagnostics,
    }

    return render(request, 'classifier/diagnostic.html', context)

# ========== HELPER FUNCTIONS ==========

def load_model_and_metadata(model_type):
    """Load classification model"""
    model_type = model_type.lower()
    if model_type not in MODEL_PATHS:
        return None, None, None, f"Invalid model type: {model_type}"
    
    if model_type in _model_cache:
        cached = _model_cache[model_type]
        return cached['model'], cached['class_mapping'], cached['breed_types'], None
    
    model_path = MODEL_PATHS[model_type]
    class_path = CLASS_NAMES_PATHS[model_type]
    
    if not model_path.exists():
        return None, None, None, f"Model file not found: {model_path}"
    if not class_path.exists():
        return None, None, None, f"Class file not found: {class_path}"
    
    try:
        with open(class_path, 'r', encoding='utf-8') as f:
            class_list = json.load(f)
            class_mapping = {str(i): name for i, name in enumerate(class_list)}
            breed_types = {name: model_type for name in class_list}
    except Exception as e:
        return None, None, None, f"Error reading classes: {e}"
    
    if TENSORFLOW_AVAILABLE:
        try:
            model = load_model(str(model_path))
            print(f"✅ {model_type.title()} model loaded")
        except Exception as e:
            return None, None, None, f"Error loading model: {e}"
    else:
        return None, None, None, "TensorFlow not available"
    
    _model_cache[model_type] = {
        'model': model,
        'class_mapping': class_mapping,
        'breed_types': breed_types,
        'loaded': True
    }
    
    return model, class_mapping, breed_types, None

def preprocess_image(image):
    """Prepare image for model"""
    if image.mode != 'RGB':
        image = image.convert('RGB')
    image_resized = image.resize(TARGET_SIZE)
    img_array = np.array(image_resized, dtype=np.float32) / 255.0
    return np.expand_dims(img_array, axis=0)