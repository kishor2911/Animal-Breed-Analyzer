# train_model.py
import os
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import matplotlib.pyplot as plt
import json
import numpy as np
from sklearn.utils.class_weight import compute_class_weight
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import argparse
import datetime

# === CONFIGURATION ===
DATASET_BASE_DIR = "dataset"
IMG_SIZE = (224, 224)
BATCH_SIZE = 32
EPOCHS = 30
MODEL_DIR = "models"

os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs("outputs", exist_ok=True)

def get_animal_config(animal_type):
    """Get configuration for specific animal type"""
    configs = {
        "cow": {
            "dataset_dir": os.path.join(DATASET_BASE_DIR, "Cow"),
            "model_name": "cow_breed_model.keras",
            "class_names": "cow_class_names.json"
        },
        "buffalo": {
            "dataset_dir": os.path.join(DATASET_BASE_DIR, "Buffalo"), 
            "model_name": "buffalo_breed_model.keras",
            "class_names": "buffalo_class_names.json"
        },
        "dog": {
            "dataset_dir": os.path.join(DATASET_BASE_DIR, "Dog"),
            "model_name": "dog_breed_model.keras", 
            "class_names": "dog_class_names.json"
        },
        "cat": {
            "dataset_dir": os.path.join(DATASET_BASE_DIR, "Cat"),
            "model_name": "cat_breed_model.keras",
            "class_names": "cat_class_names.json"
        }
    }
    return configs.get(animal_type.lower(), configs["buffalo"])

def analyze_dataset(dataset_dir):
    """Analyze the dataset for class distribution and potential issues"""
    if not os.path.exists(dataset_dir):
        raise ValueError(f"Dataset directory not found: {dataset_dir}")
    
    classes = [d for d in os.listdir(dataset_dir) 
               if os.path.isdir(os.path.join(dataset_dir, d))]
    class_counts = {}
    
    print(f"\n📊 Analyzing dataset: {dataset_dir}")
    for class_name in classes:
        class_path = os.path.join(dataset_dir, class_name)
        num_images = len([f for f in os.listdir(class_path) 
                        if f.lower().endswith(('.png', '.jpg', '.jpeg'))])
        class_counts[class_name] = num_images
        print(f"   📁 {class_name}: {num_images} images")
    
    total_images = sum(class_counts.values())
    print(f"   📈 Total images: {total_images}")
    
    return class_counts, classes

def get_datasets(animal_type):
    """Load dataset and prepare training/validation pipelines"""
    config = get_animal_config(animal_type)
    dataset_dir = config["dataset_dir"]
    
    # First analyze the dataset
    class_counts, classes = analyze_dataset(dataset_dir)
    
    if len(classes) < 2:
        raise ValueError(f"Need at least 2 classes for classification. Found {len(classes)}")

    train_ds = tf.keras.preprocessing.image_dataset_from_directory(
        dataset_dir,
        validation_split=0.2,
        subset="training",
        seed=42,
        image_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        label_mode='int'
    )

    val_ds = tf.keras.preprocessing.image_dataset_from_directory(
        dataset_dir,
        validation_split=0.2,
        subset="validation",
        seed=42,
        image_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        label_mode='int'
    )

    # Save class names
    class_names = train_ds.class_names
    num_classes = len(class_names)
    print(f"🎯 Found {num_classes} classes: {class_names}")

    # Calculate class weights to handle imbalance
    print("\n⚖️ Calculating class weights...")
    labels = []
    for _, batch_labels in train_ds:
        labels.extend(batch_labels.numpy())
    
    class_weights = compute_class_weight(
        'balanced',
        classes=np.unique(labels),
        y=labels
    )
    class_weight_dict = {i: weight for i, weight in enumerate(class_weights)}
    print(f"📋 Class weights: {class_weight_dict}")

    # Enhanced data augmentation
    def augment_data(image, label):
        # Random flips
        image = tf.image.random_flip_left_right(image)
        
        # Random brightness and contrast
        image = tf.image.random_brightness(image, 0.2)
        image = tf.image.random_contrast(image, 0.8, 1.2)
        
        # Random rotation (90 degree multiples)
        k = tf.random.uniform([], 0, 4, dtype=tf.int32)
        image = tf.image.rot90(image, k=k)
        
        # Ensure image values are valid
        image = tf.clip_by_value(image, 0.0, 255.0)
        
        return image, label

    # Apply preprocessing
    def preprocess_data(image, label):
        image = tf.keras.applications.mobilenet_v2.preprocess_input(image)
        return image, label

    # Apply preprocessing to both datasets
    train_ds = train_ds.map(preprocess_data, num_parallel_calls=tf.data.AUTOTUNE)
    val_ds = val_ds.map(preprocess_data, num_parallel_calls=tf.data.AUTOTUNE)

    # Create augmented dataset
    train_ds_augmented = train_ds.map(
        augment_data,
        num_parallel_calls=tf.data.AUTOTUNE
    )

    # Combine original and augmented data
    train_ds = train_ds.concatenate(train_ds_augmented)

    AUTOTUNE = tf.data.AUTOTUNE
    train_ds = train_ds.cache().shuffle(1000).prefetch(buffer_size=AUTOTUNE)
    val_ds = val_ds.cache().prefetch(buffer_size=AUTOTUNE)

    return train_ds, val_ds, class_names, class_weight_dict, config

def build_model(num_classes):
    """Build an enhanced CNN model with better architecture"""
    # Data augmentation as part of the model
    data_augmentation = keras.Sequential([
        layers.RandomFlip("horizontal_and_vertical"),
        layers.RandomRotation(0.1),
        layers.RandomZoom(0.1),
        layers.RandomContrast(0.1),
    ])

    # Use pre-trained model
    base_model = keras.applications.MobileNetV2(
        input_shape=(*IMG_SIZE, 3),
        include_top=False,
        weights="imagenet"
    )
    base_model.trainable = False

    inputs = keras.Input(shape=(*IMG_SIZE, 3))
    x = data_augmentation(inputs)
    x = base_model(x, training=False)
    
    # Enhanced classification head
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.BatchNormalization()(x)
    x = layers.Dense(256, activation='relu')(x)
    x = layers.Dropout(0.5)(x)
    x = layers.BatchNormalization()(x)
    x = layers.Dense(128, activation='relu')(x)
    x = layers.Dropout(0.3)(x)
    outputs = layers.Dense(num_classes, activation="softmax")(x)

    model = keras.Model(inputs, outputs)
    
    # Use a lower learning rate for more stable training
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=1e-4),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"]
    )

    return model, base_model

def plot_training_results(history, animal_type, history_fine=None):
    """Plot comprehensive training results"""
    if history_fine:
        # Combine histories
        acc = history.history["accuracy"] + history_fine.history["accuracy"]
        val_acc = history.history["val_accuracy"] + history_fine.history["val_accuracy"]
        loss = history.history["loss"] + history_fine.history["loss"]
        val_loss = history.history["val_loss"] + history_fine.history["val_loss"]
        
        # Mark fine-tuning start
        fine_tune_start = len(history.history["accuracy"])
    else:
        acc = history.history["accuracy"]
        val_acc = history.history["val_accuracy"]
        loss = history.history["loss"]
        val_loss = history.history["val_loss"]
        fine_tune_start = None

    epochs = range(1, len(acc) + 1)

    plt.figure(figsize=(15, 5))
    
    plt.subplot(1, 3, 1)
    plt.plot(epochs, acc, 'b-', label="Training Accuracy")
    plt.plot(epochs, val_acc, 'r-', label="Validation Accuracy")
    if fine_tune_start:
        plt.axvline(x=fine_tune_start, color='g', linestyle='--', label='Fine-tuning Start')
    plt.legend()
    plt.title(f"{animal_type.title()} - Accuracy")
    plt.xlabel("Epochs")
    plt.ylabel("Accuracy")

    plt.subplot(1, 3, 2)
    plt.plot(epochs, loss, 'b-', label="Training Loss")
    plt.plot(epochs, val_loss, 'r-', label="Validation Loss")
    if fine_tune_start:
        plt.axvline(x=fine_tune_start, color='g', linestyle='--', label='Fine-tuning Start')
    plt.legend()
    plt.title(f"{animal_type.title()} - Loss")
    plt.xlabel("Epochs")
    plt.ylabel("Loss")

    plt.tight_layout()
    plt.savefig(f"outputs/{animal_type}_training_history.png", dpi=300, bbox_inches='tight')
    plt.show()

def evaluate_model(model, val_ds, class_names, animal_type):
    """Comprehensive model evaluation"""
    print(f"\n=== {animal_type.upper()} MODEL EVALUATION ===")
    
    # Get predictions
    y_true = []
    y_pred = []
    
    for images, labels in val_ds:
        y_true.extend(labels.numpy())
        predictions = model.predict(images, verbose=0)
        y_pred.extend(np.argmax(predictions, axis=1))
    
    y_true = np.array(y_true)
    y_pred = np.array(y_pred)
    
    # Classification report
    print("\n📊 Classification Report:")
    print(classification_report(y_true, y_pred, target_names=class_names))
    
    # Confusion matrix
    plt.figure(figsize=(10, 8))
    cm = confusion_matrix(y_true, y_pred)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=class_names, yticklabels=class_names)
    plt.title(f'{animal_type.title()} - Confusion Matrix')
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')
    plt.xticks(rotation=45)
    plt.yticks(rotation=0)
    plt.tight_layout()
    plt.savefig(f"outputs/{animal_type}_confusion_matrix.png", dpi=300, bbox_inches='tight')
    plt.show()
    
    # Calculate per-class accuracy
    print("\n🎯 Per-class Accuracy:")
    for i, class_name in enumerate(class_names):
        class_mask = y_true == i
        if np.sum(class_mask) > 0:
            class_accuracy = np.sum(y_pred[class_mask] == i) / np.sum(class_mask)
            print(f"   {class_name}: {class_accuracy:.3f}")

def train_animal_model(animal_type):
    """Enhanced training pipeline for specific animal type"""
    train_ds, val_ds, class_names, class_weight_dict, config = get_datasets(animal_type)
    num_classes = len(class_names)
    
    print(f"\n🚀 Training {animal_type} model with {num_classes} classes")

    model, base_model = build_model(num_classes)
    
    # Enhanced callbacks
    model_path = os.path.join(MODEL_DIR, config["model_name"])
    
    callbacks = [
        keras.callbacks.ModelCheckpoint(
            model_path, 
            save_best_only=True, 
            monitor="val_accuracy",
            mode='max'
        ),
        keras.callbacks.EarlyStopping(
            patience=10, 
            restore_best_weights=True,
            monitor='val_accuracy',
            mode='max'
        ),
        keras.callbacks.ReduceLROnPlateau(
            factor=0.5, 
            patience=5,
            min_lr=1e-7,
            monitor='val_accuracy',
            mode='max'
        )
    ]

    print(f"\n=== PHASE 1: {animal_type.upper()} FEATURE EXTRACTION ===")
    history = model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=EPOCHS,
        callbacks=callbacks,
        class_weight=class_weight_dict,
        verbose=1
    )

    print(f"\n=== PHASE 2: {animal_type.upper()} FINE-TUNING ===")
    # Unfreeze more layers for fine-tuning
    base_model.trainable = True
    
    # Fine-tune from this layer onwards
    fine_tune_at = 100
    
    # Freeze all the layers before the `fine_tune_at` layer
    for layer in base_model.layers[:fine_tune_at]:
        layer.trainable = False

    # Recompile with lower learning rate
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=1e-5),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"]
    )

    fine_tune_epochs = 15
    total_epochs = EPOCHS + fine_tune_epochs

    history_fine = model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=total_epochs,
        initial_epoch=history.epoch[-1],
        callbacks=callbacks,
        class_weight=class_weight_dict,
        verbose=1
    )

    # Plot results
    plot_training_results(history, animal_type, history_fine)
    
    # Evaluate model
    evaluate_model(model, val_ds, class_names, animal_type)

    # Save final model
    model.save(model_path)
    
    # Save class names
    class_names_path = os.path.join(MODEL_DIR, config["class_names"])
    with open(class_names_path, "w") as f:
        json.dump(class_names, f, indent=2)
    
    # Save model info - FIXED: Convert TensorFlow objects to native Python types
    model_info = {
        'animal_type': animal_type,
        'class_names': class_names,
        'img_size': [int(dim) for dim in IMG_SIZE],  # Convert to list of ints
        'num_classes': int(num_classes),  # Convert to int
        'training_date': datetime.datetime.now().isoformat(),  # Use Python datetime
        'final_accuracy': float(history_fine.history['val_accuracy'][-1]),  # Convert to float
        'final_loss': float(history_fine.history['val_loss'][-1])  # Convert to float
    }
    
    info_path = os.path.join(MODEL_DIR, f"{animal_type}_model_info.json")
    with open(info_path, "w") as f:
        json.dump(model_info, f, indent=2)

    print(f"✅ {animal_type} model saved to {model_path}")
    print(f"✅ {animal_type} class names saved to {class_names_path}")
    print(f"✅ {animal_type} model info saved to {info_path}")
    
    # Final validation
    print(f"\n=== {animal_type.upper()} FINAL VALIDATION ===")
    final_loss, final_accuracy = model.evaluate(val_ds, verbose=0)
    print(f"🎉 Final Validation Accuracy: {final_accuracy:.4f}")
    print(f"📉 Final Validation Loss: {final_loss:.4f}")
    
    return model, class_names

def train_all_animals():
    """Train models for all available animal types"""
    animal_types = ["cow", "buffalo", "dog", "cat"]
    trained_models = {}
    
    for animal_type in animal_types:
        try:
            config = get_animal_config(animal_type)
            if os.path.exists(config["dataset_dir"]):
                print(f"\n{'='*50}")
                print(f"🐾 TRAINING {animal_type.upper()} MODEL")
                print(f"{'='*50}")
                model, class_names = train_animal_model(animal_type)
                trained_models[animal_type] = {
                    'model': model,
                    'class_names': class_names
                }
            else:
                print(f"⚠️ Dataset not found for {animal_type}: {config['dataset_dir']}")
        except Exception as e:
            print(f"❌ Error training {animal_type} model: {e}")
            import traceback
            traceback.print_exc()
            continue
    
    return trained_models

if __name__ == "__main__":
    # Set random seeds for reproducibility
    tf.random.set_seed(42)
    np.random.seed(42)
    
    # Disable TensorFlow warnings for cleaner output
    tf.get_logger().setLevel('ERROR')
    
    parser = argparse.ArgumentParser(description='Train animal breed classification models')
    parser.add_argument('--animal', type=str, default='all', 
                       choices=['all', 'cow', 'buffalo', 'dog', 'cat'],
                       help='Animal type to train (default: all)')
    
    args = parser.parse_args()
    
    try:
        if args.animal == 'all':
            trained_models = train_all_animals()
            print(f"\n🎊 Training completed! Models trained for: {list(trained_models.keys())}")
        else:
            model, class_names = train_animal_model(args.animal)
            print(f"\n🎊 {args.animal} model training completed successfully!")
            
    except Exception as e:
        print(f"💥 Critical error during training: {e}")
        import traceback
        traceback.print_exc()