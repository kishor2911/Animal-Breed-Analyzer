import streamlit as st
import os
import time
from datetime import datetime
from dotenv import load_dotenv
import google.generativeai as genai
import requests

# Load environment variables
load_dotenv()

# Page configuration
st.set_page_config(
    page_title="Gemini AI Chatbot",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');

/* ================= GLOBAL ================= */
html, body, [class*="css"] {
    font-family: 'Inter', sans-serif !important;
    color: #000000 !important;
}

/* ================= APP BACKGROUND ================= */
/* We keep the main container white to satisfy your "White & Green" requirement */
.stApp {
     background-color: #2E3B44 !important; /* Lighter tint of charcoal for depth */
}

/* ================= HEADER ================= */
header[data-testid="stHeader"] {
    background-color: #2E7D32 !important;
}
header[data-testid="stHeader"] * {
    color: #FFFFFF !important;
}

/* ================= SIDEBAR ================= */
section[data-testid="stSidebar"] {
    background-color: #F1F8E9 !important;
    border-right: 1px solid #C8E6C9;
}
section[data-testid="stSidebar"] * {
    color: #000000 !important;
}

/* ================= CHAT AREA (CHARCOAL) ================= */
section.main {
    background-color: #36454F !important;  /* CHARCOAL GRAY */
    padding-bottom: 80px;
}

/* ================= CHAT MESSAGE CONTAINER ================= */
[data-testid="stChatMessage"] {
    background: transparent !important;
    padding: 10px !important;
}

/* ================= ASSISTANT MESSAGE ================= */
[data-testid="stChatMessage"][data-role="assistant"] .stMarkdown,
[data-testid="stChatMessage"][data-role="assistant"] .stMarkdown * {
    background-color: #E5E5E5 !important;
    color: #000000 !important;
    padding: 12px 16px;
    border-radius: 15px 15px 15px 5px;
    max-width: 75%;
    font-size: 15px;
    line-height: 1.6;
}

/* ================= USER MESSAGE ================= */
[data-testid="stChatMessage"][data-role="user"] .stMarkdown,
[data-testid="stChatMessage"][data-role="user"] .stMarkdown * {
    background-color: #2E7D32 !important;
    color: #FFFFFF !important;
    padding: 12px 16px;
    border-radius: 15px 15px 5px 15px;
    max-width: 75%;
    font-size: 15px;
    line-height: 1.6;
}

/* ================= CHAT INPUT (DARK CHARCOAL) ================= */
div[data-testid="stChatInput"] {
    background-color: #2E3B44 !important; /* Lighter tint of charcoal for depth */
    border-radius: 30px !important;
    padding: 8px 12px !important;
}

div[data-testid="stChatInput"] textarea {
    background-color: transparent !important;
    color: #FFFFFF !important;
    font-size: 15px !important;
    border: none !important;
}

/* ================= BUTTONS ================= */
div.stButton > button {
    background-color: #2E7D32 !important;
    color: #FFFFFF !important;
    border-radius: 10px !important;
    font-weight: 600;
}
</style>
""", unsafe_allow_html=True)


class GeminiChatBot:
    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY")
        self.available_models = []
        self.model = None
        self.chat = None
        
    def get_available_models(self):
        """Get list of available models"""
        try:
            genai.configure(api_key=self.api_key)
            models = genai.list_models()
            self.available_models = [m.name for m in models]
            return self.available_models
        except Exception as e:
            st.error(f"Error getting models: {e}")
            return []
    
    def find_best_model(self):
        """Find the best available Gemini model"""
        preferred_models = [
            "gemini-1.5-flash-latest",
            "gemini-1.5-pro-latest", 
            "gemini-1.0-pro-latest",
            "models/gemini-pro",
            "models/gemini-pro-vision"
        ]
        
        for model_name in preferred_models:
            if model_name in self.available_models:
                return model_name
        
        # If no preferred model found, return first Gemini model
        for model_name in self.available_models:
            if "gemini" in model_name.lower():
                return model_name
        
        return None
    
    def initialize(self):
        """Initialize the chatbot"""
        if not self.api_key:
            st.error("❌ API Key not found in .env file")
            return False
        
        try:
            # Configure API
            genai.configure(api_key=self.api_key)
            
            # Get available models
            self.get_available_models()
            
            # Find best model
            model_name = self.find_best_model()
            
            if not model_name:
                st.error("❌ No Gemini models available. Check your API key permissions.")
                return False
            
            # Initialize model
            self.model = genai.GenerativeModel(model_name)
            self.chat = self.model.start_chat(history=[])
            
            st.sidebar.success(f"✅ Connected to: {model_name}")
            return True
            
        except Exception as e:
            st.error(f"❌ Initialization failed: {str(e)}")
            return False
    
    def send_message(self, message):
        """Send message to Gemini"""
        try:
            if not self.chat:
                if not self.initialize():
                    return "❌ Chatbot not initialized"
            
            response = self.chat.send_message(
                message,
                generation_config=genai.types.GenerationConfig(
                    temperature=float(os.getenv("DEFAULT_TEMPERATURE", "0.7")),
                    max_output_tokens=int(os.getenv("DEFAULT_MAX_TOKENS", "1000"))
                )
            )
            return response.text
            
        except Exception as e:
            return f"❌ Error: {str(e)}"

# Initialize session state
if 'chatbot' not in st.session_state:
    st.session_state.chatbot = GeminiChatBot()

if 'messages' not in st.session_state:
    st.session_state.messages = []

if 'initialized' not in st.session_state:
    st.session_state.initialized = False

# Sidebar
with st.sidebar:
    st.title("⚙️ Settings")
    st.divider()
   
    # This button will directly open the link in a new tab
    st.link_button("🏠", "http://127.0.0.1:8000/", help="Go to Home")
    # API Status
    st.subheader("🔌 API Status")
    if st.session_state.chatbot.api_key:
        st.success(f"✅ Key: `{st.session_state.chatbot.api_key[:15]}...`")
    else:
        st.error("❌ No API Key")
    
    # Model Info
    st.subheader("🤖 Model Info")
    
    if st.button("🔄 Check Available Models"):
        models = st.session_state.chatbot.get_available_models()
        if models:
            st.success(f"✅ Found {len(models)} models")
            with st.expander("View All Models"):
                for model in models:
                    st.text(f"• {model}")
        else:
            st.error("❌ No models found")
    
    # Temperature
    temperature = st.slider(
        "Creativity (Temperature)",
        min_value=0.0,
        max_value=1.0,
        value=0.7,
        step=0.1
    )
    os.environ["DEFAULT_TEMPERATURE"] = str(temperature)
    
    # Initialize button
    if st.button("🚀 Initialize Chatbot", type="primary"):
        with st.spinner("Connecting to Gemini..."):
            if st.session_state.chatbot.initialize():
                st.session_state.initialized = True
                st.success("✅ Chatbot ready!")
                time.sleep(1)
                st.rerun()
            else:
                st.error("❌ Initialization failed")
    
    st.divider()
    st.caption("Made with ❤️ using Gemini API")

# Main chat interface
st.title("🤖 Gemini AI Chatbot")
st.caption("Ask me anything! I'm powered by Google's Gemini AI")

# Display chat messages
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# Chat input
if prompt := st.chat_input("Type your message here..."):
    # Add user message
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)
    
    # Get response
    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            response = st.session_state.chatbot.send_message(prompt)
            st.markdown(response)
    
    # Add assistant message
    st.session_state.messages.append({"role": "assistant", "content": response})


# Clear chat button
if st.session_state.messages:
    if st.button("🗑️ Clear Chat"):
        st.session_state.messages = []
        st.rerun()